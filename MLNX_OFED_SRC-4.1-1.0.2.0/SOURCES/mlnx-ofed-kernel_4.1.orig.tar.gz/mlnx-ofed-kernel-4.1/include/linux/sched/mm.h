#ifndef COMPAT_LINUX_SCHED_MM_H
#define COMPAT_LINUX_SCHED_MM_H

#include "../../../compat/config.h"

#ifdef HAVE_SCHED_MM_H
#include_next <linux/sched/mm.h>
#endif

#endif /* COMPAT_LINUX_SCHED_MM_H */
