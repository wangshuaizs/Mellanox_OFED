#ifndef SCSI_SCSI_TRANSPORT_BACKPORT_TO_2_6_22_H
#define SCSI_SCSI_TRANSPORT_BACKPORT_TO_2_6_22_H

#include <scsi/scsi_device.h>
#include_next <scsi/scsi_transport.h>

#endif
