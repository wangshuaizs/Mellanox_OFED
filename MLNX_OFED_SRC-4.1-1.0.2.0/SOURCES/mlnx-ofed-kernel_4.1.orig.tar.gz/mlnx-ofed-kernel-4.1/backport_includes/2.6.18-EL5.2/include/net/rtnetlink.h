#ifndef __BACKPORT_RTNETLINK_TO_2_6_27__
#define __BACKPORT_RTNETLINK_TO_2_6_27__

#include <linux/rtnetlink.h>

#endif
