#ifndef ASM_UNALIGNED_BACKPORT_TO_2_6_27_H
#define ASM_UNALIGNED_BACKPORT_TO_2_6_27_H

#include <linux/unaligned/access_ok.h>
#include_next <asm/unaligned.h>

#endif
