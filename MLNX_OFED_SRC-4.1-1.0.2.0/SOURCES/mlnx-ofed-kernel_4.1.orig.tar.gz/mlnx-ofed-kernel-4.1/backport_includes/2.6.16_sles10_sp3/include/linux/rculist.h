#ifndef LINUX_RCULIST_BACKPORT_tO_2_6_26_H
#define LINUX_RCULIST_BACKPORT_tO_2_6_26_H

#include_next <linux/list.h>
#include_next <linux/rcupdate.h>

#endif
