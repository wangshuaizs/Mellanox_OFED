#ifndef __BACKPORT_LINUX_SEMAPHORE_H_TO_2_6_25__
#define __BACKPORT_LINUX_SEMAPHORE_H_TO_2_6_25__

#include_next <asm/semaphore.h>

#endif /* __BACKPORT_LINUX_SEMAPHORE_H_TO_2_6_25__ */
