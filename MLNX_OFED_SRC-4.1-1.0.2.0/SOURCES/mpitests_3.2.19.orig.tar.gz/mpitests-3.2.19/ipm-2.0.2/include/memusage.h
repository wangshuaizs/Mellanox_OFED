
#ifndef MEMUSAGE_H_INCLUDED
#define MEMUSAGE_H_INCLUDED

int ipm_get_procmem(double *bytes);

#endif 
