
#ifndef MOD_MACHTOPO_H_INCLUDED
#define MOD_MACHTOPO_H_INCLUDED

void ipm_get_machtopo();

#endif /* MOD_MACHTOPO_H_INCLUDED */
