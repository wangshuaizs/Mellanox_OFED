.. Define the common option -G

**-G, --Guid**     The address specified is a Port GUID

