
#include "mdep/windows/dapl_mdep_user.c"
