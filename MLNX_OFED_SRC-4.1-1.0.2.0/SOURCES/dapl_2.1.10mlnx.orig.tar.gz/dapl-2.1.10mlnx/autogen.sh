#! /bin/sh

set -x
mkdir -p config m4
autoreconf -vi
