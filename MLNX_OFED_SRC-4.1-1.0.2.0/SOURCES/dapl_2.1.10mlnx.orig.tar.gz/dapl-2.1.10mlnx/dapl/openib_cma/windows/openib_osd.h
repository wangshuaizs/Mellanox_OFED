#include <rdma/rdma_cma.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#define ntohll _byteswap_uint64
#define htonll _byteswap_uint64
